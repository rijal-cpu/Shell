=== FitnessBase ===
Contributors: ThemeArile
Author: ThemeArile
Requires at least: 4.7
Tested up to: 6.7
Requires PHP: 5.6
Version: 3.3.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: one-column, two-columns, right-sidebar, flexible-header, custom-background, custom-header, custom-menu, editor-style, featured-images, footer-widgets, post-formats, theme-options, threaded-comments, rtl-language-support, translation-ready, full-width-template, custom-logo, blog, e-commerce, portfolio

== Description ==

Description: FitnessBase theme is a versatile theme that can be used for a variety of website types, gym, health clubs, yoga, and fitness center websites included. This theme comes with professionally designed layouts and its compatible with WooCommerce, Elementor, Contact Form 7, Jetpack, Yoast SEO, Google Analytics, and many other popular WordPress plugins. Not only that, but this is also a very lightweight theme that is load with a single click in no time. The theme is completely responsive and mobile-friendly and that your users can access your site from any device. As well as sophisticated plus it has some exotic features like customization and clean code, advanced typography, sticky menu, logo upload, header image, Bootstrap 4 framework, built with SEO in mind, and translation ready (WPML, Polylang). Check the demo of ConsultStreet Pro https://themearile.com/consultstreet-pro-theme/.

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in FitnessBase in the search form and press the 'Enter' key on your keyboard.
3. Click on the 'Activate' button to use your new theme right away.

== Copyright ==

FitnessBase WordPress Theme, Copyright (c) 2020, ThemeArile
FitnessBase is distributed under the terms of the GNU GPLs

== Credits ==

* Underscores - (C) 2012-2017 Automattic, Inc. - http://underscores.me/
License: GPLv2 or later (https://www.gnu.org/licenses/gpl-2.0.html) 

* Font Awesome by @davegandy - http://fontawesome.io/
License: (Font: SIL OFL 1.1, CSS: MIT License)

* WOW - by Matthieu Aussaguel - mynameismatthieu.com
License: GNU GPL license v3

* Owl Carousel, (C) 2013 - 2018, David Deutsch
Source: https://github.com/OwlCarousel2/OwlCarousel2/
License: [MIT](http://opensource.org/licenses/MIT)

* Bootstrap, (C) 2011 - 2018, The Bootstrap Authors [MIT]
Source: https://github.com/twbs/bootstrap
License: [MIT](http://opensource.org/licenses/MIT)

* Admin Page  
License -  GNU GENERAL PUBLIC LICENSE (https://www.gnu.org/licenses/)
Source: https://blossomthemes.com/licensing-policy/

* SmartMenus - Copyright (c) Vasil Dinkov, Vadikom Web Ltd. - http://www.smartmenus.org/
License: MIT (http://opensource.org/licenses/MIT)

* Screenshot Banner Image - https://pxhere.com/en/photo/1366500
License: CC0 Public Domain

* About Section Image - https://pxhere.com/en/photo/917150
License: CC0 Public Domain

* Page header Image - https://pxhere.com/en/photo/1621389
License: CC0 Public Domain

* Service One Image - https://pxhere.com/en/photo/714756
License: CC0 Public Domain

* Service Two Image - https://pxhere.com/en/photo/1621389
License: CC0 Public Domain

* Service Three Image - https://pxhere.com/en/photo/714756
License: CC0 Public Domain

== Changelog ==

= Version 3.3.6
* We have updated the footer copyright content.

= Version 3.3.5
* Added the bottom space of the wp-block-details widget in the sidebar widget area.

= Version 3.3.4
* We have fixed the social icons space and color issue in the wp-block-social-links Widget post area.

= Version 3.3.3
* We have added the bottom space and border color for the wp-block-details in the footer sidebar.

= Version 3.3.2
* We have fixed the issue in comment.php file.

= Version 3.3.1
* We have added the bottom space of the wp-block-query-pagination in the blog post area.

= Version 3.3.0
* We have added the list style of the wp-block-latest-posts in the blog post area.

= Version 3.2.9
* We have added the bottom space of the "Leave a reply" title in the comment area.

= Version 3.2.8
* Removed the unnecessary border from the wp-block-search block in the blog post area.

= Version 3.2.7
* We have added the hover default color of the wp-block-page-list in the blog post area.

= Version 3.2.6
* We have removed the unnecessary left space of the wp-block-post-template in the blog post area.

= Version 3.2.5
* We have removed the background and shadow from the wp-block-post in the blog post area.

= Version 3.2.4
* We have Updated footer copyright text.

= Version 3.2.3
* We have reduced the bottom space of the wp-block-archives-list widget in the blog post area.

= Version 3.2.2
* We have added the bottom space of the unordered list element in the Footer sidebar widget area.

= Version 3.2.1
* Removed the bottom space of the submit button from the comment form.

= Version 3.2.0
* Removed the unnecessary color css in the sidebar widgets from the theme-default.css file.

= Version 3.1.9
* Added the theme default color for anchor/hyperlink for the ordered and unordered list elements in the sidebar widget area.

= Version 3.1.8
* We have added the bottom space of the ordered and unordered list elements in the sidebar widget area.

= Version 3.1.7
* We have added the bottom space of the ordered list element in the blog post content area.

= Version 3.1.6
* We have added the bottom space of the unordered list element in the blog post content area.

= Version 3.1.5
* Removed the unnecessary underline from heading 2 tag for footer widget area.

= Version 3.1.4
* Removed the unnecessary underline from heading 2 tag for sidebar widget area.

= Version 3.1.3
* Added the theme default color for anchor/hyperlink for the wp-block-quote in the footer sidebar widget area.

= Version 3.1.2
* Removed the unnecessary bottom space from the wp-block-columns widget in the footer sidebar area.

= Version 3.1.1
* Fixed the hover color style issue in Blockquote post format for blog post area.

= Version 3.1.0
* Added the line-height in the recent comments widget for the sidebar area.

= Version 3.0.9
* Added the left space in the wp-block-rss widget for the blog post area.

= Version 3.0.8
* Added the left space in the archives widget for the blog post area.

= Version 3.0.7
* Added the list style in the archives widget for the blog post area.

= Version 3.0.6
* Added the left space in the commetns widget for the blog post area.

= Version 3.0.5
* Fixed the hover color issue of the link on the image for blog post area.

= Version 3.0.4
* Fixed the last-child bottom space of the ul in the blog post area.

= Version 3.0.3
* Fixed the underline color issue in the post-format audio for blog area.

= Version 3.0.2
* Added list style icon in the RSS Feed widget for the blog post area.

= Version 3.0.1
* Reduced the bottom space of the wp-block-image widget in the sidebar area.

= Version 2.9.9
* Added the theme default color for anchor/hyperlink for the wp-block-quote in the sidebar widget area.

= Version 2.9.8
* Added the theme default color for anchor/hyperlink for the figcaption wp-block-image in the footer sidebar widget area.

= Version 2.9.7
* Removed the bottom space for the wp-block-image widget in the sidebar.

= Version 2.9.6
* Added the theme default color for anchor/hyperlink for the figcaption wp-block-image in the sidebar widget area.

= Version 2.9.5
* Fixed the wp-caption anchor link hover color issue in the blog post area.

= Version 2.9.4
* We have changed the hover color of the latest-commets title in the blog post area.

= Version 2.9.3
* Fixed the text color issue in wp-block-button widget in the sidebar.

= Version 2.9.2
* Fixed the footer-sidebar section spacing issue.

= Version 2.9.1
* Updated footer copyright text.

= Version 2.9.0
* Removed the bottom space of the wp-block-media-text widget in the sidebar.

= Version 2.8.9
* Remove the top space for the wp-block-latest-comments widget in the sidebar.

= Version 2.8.8
* Fixed the table border color issue in the blog post area.

= Version 2.8.7
* Reduced the bottom space for the wp-block-latest-comments in the blog post area.

= Version 2.8.6
* Added the border-bottom color for the wp-block-latest-comments in the blog post area.

= Version 2.8.5
* Fixed the button css issue in the wp-block-file for blog Post.

= Version 2.8.4
* Fixed the table color issue for the wp-block-table widget in the sidebar area.

= Version 2.8.3
* Fixed the color issue of the paragraph and cite tag for wp-block-pullquote widget in the footer sidebar.

= Version 2.8.2
* Removed unnecessary top and bottom space from wp-block-pullquote element in blog post area.

= Version 2.8.1
* Removed unnecessary CSS from theme-default CSS file because it conflicts with other anchor list items.

= Version 2.8.0
* Added the theme default color for anchor/hyperlink in the list widget for sidebar area.

= Version 2.7.9
* Added the theme default color for anchor/hyperlink in the is-nowrap widget for footer sidebar area.

= Version 2.7.8
* Added the theme default color for the anchor/hyperlink in the default paragraph in the footer sidebar widget area.

= Version 2.7.7
* Changed the background color for the wp-block-verse widget in the footer sidebar widget area.

= Version 2.7.6
* Added the theme default color for the anchor/hyperlink in the default paragraph in the sidebar widget area.

= Version 2.7.5
* Added the theme default color for the anchor/hyperlink in the wp-block-read-more widget for sidebar area.

= Version 2.7.4
* Added the theme default color for the anchor/hyperlink in the stack widget for footer  sidebar area.

= Version 2.7.3
* Removed the unnecessary bottom spacing for the wp-block-quote widget in the sidebar area.

= Version 2.7.2
* Removed the unnecessary bottom spacing for the wp-block-preformatted widget in the sidebar area.

= Version 2.7.1
* Removed the unnecessary bottom spacing for the verse widget in the sidebar area.

= Version 2.7.0
* Removed the top and bottom space from the wp-block-separator widget in the sidebar area.

= Version 2.6.9
* Added the theme default color for the anchor/hyperlink in the stack widget for sidebar area.

= Version 2.6.8
* Added the theme default color for the anchor/hyperlink in the is-nowrap widget for footer sidebar area.

= Version 2.6.7
* Added the theme default color for the anchor/hyperlink in the is-nowrap widget for sidebar area.

= Version 2.6.6
* Added the theme default color for the anchor/hyperlink in the wp-block-preformatted for footer sidebar Widget.

= Version 2.6.5
* Added the theme default color for the anchor/hyperlink in the wp-block-preformatted for Sidebar Widget.

= Version 2.6.4
* Added the theme default color for anchor/hyperlink in the wp-block-table for footer Sidebar Widget.

= Version 2.6.3
* Added the theme default color for anchor/hyperlink in the wp-block-table for Sidebar Widget.

= Version 2.6.2
* Fixed the color issue in the anchor/hyperlink for the verse widget in the sidebar.

= Version 2.6.1
* Fixed the color issue in the anchor/hyperlink for the verse widget in the footer sidebar.

= Version 2.6.0
* Removed the top space from the wp-block-pullquote in the footer sidebar widget.

= Version 2.5.9
* Updated copyright string.

= Version 2.5.8
* Removed the bottom space and added the theme default color for anchor/hyperlink in the wp-block-code footer sidebar widget.

= Version 2.5.7
* Removed the bottom space and added the theme default color for anchor/hyperlink in the wp-block-code sidebar widget.

= Version 2.5.6
* Added the theme default color for anchor/hyperling in the wp-block-pullquote footer sidebar widget.

= Version 2.5.5
* Added the theme default color for logged-in link in the footer sidebar widget area.

= Version 2.5.4
* Added the theme default color for logged-in link in the Sidebar widget area.

= Version 2.5.3
* Added the theme default color for anchor tag in the footer sidebar wp-block-media-text widget area.

= Version 2.5.2
* Added the theme default color for anchor tag in the sidebar wp-block-media-text widget area.

= Version 2.5.1
* Removed the last-child space from the wp-block-rss widget in the footer-sidebar area.

= Version 2.5.0
* Removed the bottom space from the blockquote paragraph in the footer-sidebar wp-block-pullquote widget.

= Version 2.4.9
* Removed the bottom space from the wp-block-pullquote and blockquote paragraph in the sidebar widget.

= Version 2.4.8
* Added the default theme color for the wp-block-pullquote cite tag in the sidebar widget.

= Version 2.4.7
* Added the font-weight for the RSS Widget title in the footer sidebar widget.

= Version 2.4.6
* Added the font-weight for the RSS Widget title in the sidebar widget.

= Version 2.4.5
* We have remove the unnecessary bottom space from the wp-block-latest-comments widget in the sidebar.

= Version 2.4.4
* We have reduced the top space of the list style for each widget in the sidebar.

= Version 2.4.3
* Remove the bottom space for the widget_meta widget in the sidebar.

= Version 2.4.2
* Added the font-weight for the wp-block-latest-posts title in the footer-sidebar widget.

= Version 2.4.1
* Added the font-weight for the wp-block-latest-posts title in the sidebar widget.

= Version 2.4.0
* We have fixed the line-height issue of the search widget title in the sidebar.

= Version 2.3.9
* We did Reduce the unnecessary bottom space from the wp-block-columns widget in the sidebar.

= Version 2.3.8
* Remove the bottom space space for the wp-block-latest-posts__list, wp-block-latest-comments, wp-block-calendar widget in the sidebar.

= Version 2.3.7
* We did Reduce the unnecessary bottom space from the wp-block-separator widget in the sidebar.

= Version 2.3.6
* We did Reduce the unnecessary bottom space from the wp-block-cover widget in the sidebar.

= Version 2.3.5
* We did enhance the font size for the latest comment title and date in the blog post section.

= Version 2.3.4
* We did enhance the font size for the latest comment date and description in the sidebar widget.

= Version 2.3.3
* Added the font-weight for the latest comment title in the footer-sidebar widget.

= Version 2.3.2
* We did Reduce the unnecessary space between the wp-block-latest-comments in the footer-sidebar widget.

= Version 2.3.1
* We did Reduce the unnecessary space between the wp-block-latest-comments in the sidebar widget.

= Version 2.3.0
* We did enhance the font size for the latest comment title in the sidebar widget.

= Version 2.2.9
* Added the font-weight for the latest comment title in the sidebar widget.

= Version 2.2.8
* We did remove the unnecessary default color styles for headings in the sidebar widgets.

= Version 2.2.7
* We did fix the border color of the wp-block-search input box in the blog post.

= Version 2.2.6
* Added the theme default color for the logged-in widget in all sidebars.

= Version 2.2.5
* Removed the wp-block-embed widget bottom space in the sidebar.

= Version 2.2.4
* Fixed all widgets style issues according to WordPress 5.8 for all sidebars.

= Version 2.2.3
* Fixed the tags widget color style issue according to WordPress 5.8 for all sidebars.

= Version 2.2.2
* Fixed the Footer widget title style issue according to WordPress 5.8.

= Version 2.2.1
* Fixed the sidebar widget title issue according to WordPress 5.8.

= Version 2.2.0
* Fixed the calendar widget link issues like font-weight and text-underline issues.

= Version 2.1.9
* Fixed the checkbox and radio button style issues in the customizer.

= Version 2.1.8
* Removed left space to the wp-block-latest-comments in the blog post area.

= Version 2.1.7
* Added default color to widget_recent_comments list style in the sidebar area.

= Version 2.1.6
* Added default color to widget_rss title in the sidebar area.

= Version 2.1.5
* We did Input Group Search z-index Issue Fixed in the Sidebar.

= Version 2.1.4
* Added the top-bottom space for the comment date in the Block category Widgets post.

= Version 2.1.3
* Added the default hover text color to the wp-calendar-nav links.

= Version 2.1.2
* Fixed responsive issue in Block category Embeds for blog post.

= Version 2.1.1
* Fixed the text widget image space for all sidebars.

= Version 2.1.0
* Added input focus color to the detail page content area.

= Version 1.9.9
* Fixed the line height for a paragraph in the wp-block-pullquote blog post.

= Version 1.9.8
* Added the left and right space in the footer site-info.

= Version 1.9.7
* Added top border color in the wp-block-pullquote for the Block: Quote post.

= Version 1.9.6
* Fixed toggle button focus issue in sticky menu.

= Version 1.9.5
* Removed the list style from the wp-blog-archive post for the blog page template.

= Version 1.9.4
* Update the theme welcome page.

= Version 1.9.3
* Fixed the wp-block-search button background color style issue for the blog page template.

= Version 1.9.2
* Removed the blockquote content space between the paragraph and cite tag in the blockquote.

= Version 1.9.1
* Fixed the attachment image spacing issue in the Page Image Alignments.

= Version 1.9
* Removed the list style and add the bottom space from the wp-block-rss element in the Block Category Widget post.

= Version 1.8
* Fixed the wp-block-gallery bottom spacing issue in the blog page.

= Version 1.7
* This theme is fully compatible with the new version of WordPress 5.6.2.

= Version 1.6
* The distance between wp-block-cover and wp-block-cover-image is fixed by css code in blog page.

= Version 1.5
* Updated copyright string.

= Version 1.4
* Fixed the wp-block-group spacing style issue for the block category layout element in the blog page.

= Version 1.3
* Fixed the wp-block-search button style issue for the blog page template.

= Version 1.2
* Fixed the wp-block-calendar and select box style issue for the blog page template.

= Version 1.1
* Fixed the wp-block-cover-text style issue for the blog page template.

= Version 1.0
* Fixed the block button color style issue for the blog page template.

= Version 0.9
* Fixed string issue in the free vs pro file.

= Version 0.8
* Fixed anchor hover color issue for footer textwidget elements.

= Version 0.7
* Fixed add menu button css issue.

= Version 0.6
* We have fixed border-color issues for textarea elements in blog detail page.

= Version 0.5
* Added theme info section.

= Version 0.4
* Updated screenshot.

= Version 0.3
* We have fixed anchor border-color issues in these elements like post element, excerpt, text widget, and comments content.

= Version 0.2
* Updated Screenshot.

= Version 0.1
* Initial release.