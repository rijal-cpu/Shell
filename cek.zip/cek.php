<?php
/**
 * URL Auto Checker (Auto-Base + Auto-List, Accurate+Legacy) — PHP 5.3+
 * - Base path otomatis dari folder file ini
 * - Textarea otomatis terisi daftar file di folder ini (filter ekstensi umum: php, phtml, phar, pl, new)
 * - Spoof browser headers + 3-pass retry (default -> browser -> relaxed SSL)
 * - Input bisa filename (pakai Base) atau URL penuh (abaikan Base)
 */

@ini_set('display_errors', 0);
error_reporting(E_ALL);

function e($s){ return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
function ends_with_slash($s){ return strlen($s)>0 && substr($s,-1)==='/'; }
function ltrim_slash($s){ while(strlen($s)&&$s[0]==='/') $s=substr($s,1); return $s; }
function has_scheme($s){ return (stripos($s,'http://')===0 || stripos($s,'https://')===0); }

/** Base path otomatis dari lokasi file ini */
function get_default_base(){
    $https = (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off') || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT']==443);
    $scheme = $https ? 'https' : 'http';
    $host   = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : $_SERVER['SERVER_NAME'];
    $dir    = rtrim(dirname($_SERVER['REQUEST_URI']), '/\\');
    if ($dir === '') $dir = '/';
    if (!ends_with_slash($dir)) $dir .= '/';
    return $scheme.'://'.$host.$dir;
}

/** Ambil daftar file dari folder lokal tempat script berada */
function get_default_list_from_here(){
    $dir = dirname(__FILE__);                 // path filesystem folder ini
    $allow_ext = array('php','phtml','phar','pl','new'); // bisa tambah sesuai kebutuhan
    $names = array();
    if (is_dir($dir) && ($dh = opendir($dir))) {
        while (($f = readdir($dh)) !== false) {
            if ($f === '.' || $f === '..') continue;
            if (is_dir($dir.'/'.$f)) continue;
            // ambil ekstensi (case-insensitive)
            $dotpos = strrpos($f, '.');
            $ext = $dotpos !== false ? strtolower(substr($f, $dotpos+1)) : '';
            if (in_array($ext, $allow_ext)) {
                $names[] = $f;
            }
        }
        closedir($dh);
    }
    // sort case-insensitive
    natcasesort($names);
    return array_values($names);
}

/** Gabung base + nama file; baris yang sudah full URL dibiarkan */
function build_inputs($base, $lines){
    $urls = array();
    $base = trim($base);
    $use_base = ($base !== '');
    if($use_base && !ends_with_slash($base)) $base .= '/';
    foreach($lines as $ln){
        $ln = trim($ln);
        if($ln==='' || (isset($ln[0]) && $ln[0]==='#')) continue;
        if(has_scheme($ln)) $urls[] = $ln;
        else if($use_base) $urls[] = $base . ltrim_slash($ln);
        else $urls[] = $ln;
    }
    return $urls;
}

/** Low-level cURL request (3 profil) */
function do_request($url, $timeout, $profile, $cookieFile){
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    curl_setopt($ch, CURLOPT_ENCODING, "");
    curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);

    $ua_default = 'Mozilla/5.0 (compatible; URLChecker/1.0)';
    curl_setopt($ch, CURLOPT_USERAGENT, $ua_default);

    if($profile >= 1){
        $ua_browser = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
        curl_setopt($ch, CURLOPT_USERAGENT, $ua_browser);
        $headers = array(
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language: en-US,en;q=0.9,id;q=0.8',
            'Cache-Control: no-cache',
            'Pragma: no-cache'
        );
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_REFERER, $url);
        curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    }
    if($profile >= 2){
        // fallback longgar
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    }

    $body = curl_exec($ch);
    $err  = curl_error($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return array($code, $body, $err);
}

/** Fetch robust dengan heuristik “OK walau non-2xx” jika konten terbaca */
function fetch_url_robust($url, $timeout){
    if(!function_exists('curl_init')){
        return array($url, null, false, false, '', 0, 'cURL extension tidak tersedia');
    }
    $cookieFile = sys_get_temp_dir().'/urlchk_'.md5(__FILE__).'.cookie';
    $best = array('code'=>null,'body'=>'','err'=>'','profile'=>0);

    for($profile=0;$profile<3;$profile++){
        $res = do_request($url, $timeout, $profile, $cookieFile);
        $code=$res[0]; $body=$res[1]; $err=$res[2];
        if($best['code']===null || (is_int($code) && $code < ($best['code']===null?999:$best['code']))){
            $best = array('code'=>$code,'body'=>$body,'err'=>$err,'profile'=>$profile);
        }
        if(is_int($code) && $code>=200 && $code<300) break;
    }

    $code=$best['code']; $body=$best['body']; $err=$best['err'];
    $title = '';
    if($body && preg_match('~<title>(.*?)</title>~is',$body,$m)){
        $title = trim(html_entity_decode($m[1], ENT_QUOTES, 'UTF-8'));
    }
    $length = $body ? strlen($body) : 0;

    $lower = strtolower($body ? $body : '');
    $markers = array('dadsec','c99shell','r57shell','b374k','wso','filesman','mini shell','web shell','cmd.php','tty shell','shin bypassed');
    $shell = false;
    foreach($markers as $mk){ if(strpos($lower,$mk)!==false){ $shell=true; break; } }

    $ok = (is_int($code) && $code>=200 && $code<300);
    if(!$ok && $length>500 && ($shell || $title!=='')){
        $ok = true;
    }
    return array($url, ($code?$code:null), $ok, $shell, $title, (int)$length, $err);
}

/* ---------- Inisialisasi & Auto-List ---------- */
$default_base = get_default_base();           // Base otomatis (URL folder ini)
$auto_names   = get_default_list_from_here(); // List file otomatis (folder ini)
$auto_list_raw = implode("\n", $auto_names);

$results = null;
$timeout = 7;

/* ---------- Proses Form ---------- */
if($_SERVER['REQUEST_METHOD']==='POST'){
    $base = isset($_POST['base']) ? trim($_POST['base']) : $default_base;
    if($base==='') $base = $default_base;

    // Jika user tidak mengubah textarea, tetap pakai auto_list
    $list_raw = isset($_POST['list']) ? trim($_POST['list']) : $auto_list_raw;
    if($list_raw === '') $list_raw = $auto_list_raw;

    $timeout = isset($_POST['timeout']) ? (int)$_POST['timeout'] : 7;
    if($timeout<1 || $timeout>60) $timeout=7;

    $lines = preg_split('/\r\n|\r|\n/', $list_raw);
    $urls  = build_inputs($base, $lines);

    $results = array();
    foreach($urls as $u){ $results[] = fetch_url_robust($u, $timeout); }
} else {
    // GET pertama kali: isi default base & list otomatis
    $base = $default_base;
    $list_raw = $auto_list_raw;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>URL Auto Checker (Auto-Base + Auto-List)</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{font-family:Arial,Helvetica,sans-serif;max-width:980px;margin:24px auto;padding:0 12px;background:#f8f9fb}
h1{margin:0 0 12px}
form{background:#fff;border:1px solid #e3e6ee;border-radius:8px;padding:16px}
input[type=text]{width:100%;max-width:640px;padding:8px}
textarea{width:100%;height:220px;padding:8px}
button{padding:10px 16px;cursor:pointer}
table{width:100%;border-collapse:collapse;background:#fff;margin-top:16px}
th,td{border:1px solid #e3e6ee;padding:8px;font-size:14px;vertical-align:top}
th{background:#f0f3f9;text-align:left}
.bad{color:#b00020;font-weight:bold}
.good{color:#0b7a0b;font-weight:bold}
.note{color:#555}
.url a{word-break:break-all}
</style>
</head>
<body>
<h1>URL Auto Checker</h1>

<form method="post">
    <p><strong>Base path (otomatis dari folder ini, bisa diubah)</strong><br>
    <input type="text" name="base" value="<?php echo e($base); ?>" placeholder="<?php echo e($default_base); ?>"></p>

    <p><strong>Daftar nama file atau URL (otomatis dari folder ini, bisa dihapus/ubah)</strong><br>
    <textarea name="list"><?php echo e($list_raw); ?></textarea></p>

    <p>Timeout (detik): <input type="text" name="timeout" value="<?php echo e((string)$timeout); ?>" style="width:60px">
       &nbsp; <button type="submit">Cek Sekarang</button></p>

</form>

<?php if(is_array($results)): ?>
<h2>Hasil</h2>
<table>
<tr>
    <th>#</th><th>URL</th><th>Status</th><th>OK</th><th>Shell-like</th><th>Title</th><th>Length</th><th>Error</th>
</tr>
<?php
$i=0;
foreach($results as $r):
    $i++;
    $u=$r[0]; $st=$r[1]; $ok=($r[2]?'YES':'NO'); $sh=($r[3]?'YES':'NO'); $ttl=$r[4]; $len=$r[5]; $err=$r[6];
?>
<tr>
    <td><?php echo (int)$i; ?></td>
    <td class="url"><a href="<?php echo e($u); ?>" target="_blank"><?php echo e($u); ?></a></td>
    <td><?php echo e((string)$st); ?></td>
    <td class="<?php echo ($ok==='YES'?'good':'bad'); ?>"><?php echo $ok; ?></td>
    <td class="<?php echo ($sh==='YES'?'bad':''); ?>"><?php echo $sh; ?></td>
    <td><?php echo e($ttl); ?></td>
    <td><?php echo (int)$len; ?></td>
    <td><?php echo e($err); ?></td>
</tr>
<?php endforeach; ?>
</table>
<?php endif; ?>

</body>
</html>