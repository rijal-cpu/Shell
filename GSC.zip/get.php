<?php
// Fungsi untuk mengambil daftar URL dari halaman di situs
function getSiteContentList($url)
{
    // Menggunakan cURL untuk mengambil konten dari halaman
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $content = curl_exec($ch);
    curl_close($ch);

    // Memastikan bahwa konten berhasil diambil
    if ($content === false) {
        return [];
    }

    // Mencari URL dalam halaman yang diambil
    preg_match_all('/<a href="([^"]+)"/i', $content, $matches);

    // Menyaring URL yang sesuai (hanya URL dari domain yang sama)
    $urls = [];
    $parsedSourceUrl = parse_url($url);
    $sourceHost = $parsedSourceUrl['host']; // Mendapatkan host dari URL sumber

    foreach ($matches[1] as $link) {
        $parsedLink = parse_url($link);

        // Jika URL relatif (dimulai dengan '/'), tambahkan domain
        if (!isset($parsedLink['host']) && strpos($link, '/') === 0) {
            $link = $parsedSourceUrl['scheme'] . '://' . $sourceHost . $link;
        }

        // Jika URL memiliki host yang sama dengan sumber, tambahkan ke array
        if (isset($parsedLink['host']) && $parsedLink['host'] === $sourceHost) {
            $urls[] = $link;
        }
    }
    return $urls;
}

// Mendapatkan URL penuh dari halaman situs
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$fullUrl = $protocol . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

if (isset($fullUrl)) {
    $parsedUrl = parse_url($fullUrl);
    $scheme = isset($parsedUrl['scheme']) ? $parsedUrl['scheme'] : '';
    $host = isset($parsedUrl['host']) ? $parsedUrl['host'] : '';
    $path = isset($parsedUrl['path']) ? $parsedUrl['path'] : '';
    $baseUrl = $scheme . "://" . $host . $path;
    $urlAsli = str_replace("get.php", "", $baseUrl);

    // Menyusun URL sumber dari situs docautinthien.com
    $sourceUrl = "https://www.docautinthien.com"; // Ganti dengan halaman atau URL yang sesuai di situs Anda
    $urlsFromSite = getSiteContentList($sourceUrl);

    // Membuat robots.txt
    $robotsTxt = "User-agent: *" . PHP_EOL;
    $robotsTxt .= "Allow: /" . PHP_EOL;
    $robotsTxt .= "Sitemap: " . $urlAsli . "sitemap.xml" . PHP_EOL;
    file_put_contents('robots.txt', $robotsTxt);

    // Membuat sitemap.xml
    $sitemapFile = fopen("sitemap.xml", "w");
    fwrite($sitemapFile, '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL);
    fwrite($sitemapFile, '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL);

    foreach ($urlsFromSite as $url) {
        // Jika URL dimulai dengan '/', hanya tambahkan path
        if (strpos($url, '/') === 0) {
            $sitemapLink = $protocol . "://" . $host . $url;
        } else {
            // Jika URL sudah lengkap (http:// atau https://), langsung gunakan URL tersebut
            $sitemapLink = $url;
        }

        fwrite($sitemapFile, '  <url>' . PHP_EOL);
        fwrite($sitemapFile, '    <loc>' . $sitemapLink . '</loc>' . PHP_EOL);
        date_default_timezone_set('Asia/Bangkok');
        $currentTime = date('Y-m-d\TH:i:sP');
        fwrite($sitemapFile, '    <lastmod>' . $currentTime . '</lastmod>' . PHP_EOL);
        fwrite($sitemapFile, '  </url>' . PHP_EOL);
    }

    fwrite($sitemapFile, '</urlset>' . PHP_EOL);
    fclose($sitemapFile);

    echo "Sitemap.xml Selesai Dibuatkan";
} else {
    echo "https://google.com.";
}
?>